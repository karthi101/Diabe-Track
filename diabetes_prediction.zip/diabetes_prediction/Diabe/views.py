from django.contrib.auth import get_user_model
from django.contrib.auth import get_user_model


from users.models import Profile,GovernmentAdmin

User = get_user_model()
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponse
from django.db.models import Count
from django.contrib.auth.decorators import login_required

from django.shortcuts import render
from .forms import PredictionForm
import joblib
import os
import numpy as np

model_path = os.path.join(os.path.dirname(__file__), 'diabetes_model.pkl')
model = joblib.load(model_path)

def predict_view(request):
    prediction = None
    if request.method == 'POST':
        form = PredictionForm(request.POST)
        if form.is_valid():
            data = [
                form.cleaned_data['pregnancies'],
                form.cleaned_data['glucose'],
                form.cleaned_data['blood_pressure'],
                form.cleaned_data['skin_thickness'],
                form.cleaned_data['insulin'],
                form.cleaned_data['bmi'],
                form.cleaned_data['diabetes_pedigree'],
                form.cleaned_data['age'],
            ]
            prediction = model.predict([np.array(data)])[0]
    else:
        form = PredictionForm()

    return render(request, 'Diabe/predict.html', {'form': form, 'prediction': prediction})

