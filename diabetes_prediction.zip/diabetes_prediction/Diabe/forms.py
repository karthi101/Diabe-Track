from django import forms

class PredictionForm(forms.Form):
    pregnancies = forms.IntegerField(label="Pregnancies", min_value=0,max_value=11,widget=forms.NumberInput(attrs={'type': 'number'}))
    glucose = forms.IntegerField(label="Glucose Level", min_value=0,max_value=200)
    blood_pressure = forms.IntegerField(label="Blood Pressure", min_value=0,max_value=120)
    skin_thickness = forms.IntegerField(label="Skin Thickness", min_value=0,max_value=100)
    insulin = forms.IntegerField(label="Insulin Level", min_value=0,max_value=850)
    bmi = forms.FloatField(label="BMI", min_value=0.0,max_value=65.1)
    diabetes_pedigree = forms.FloatField(label="Diabetes Pedigree Function", min_value=0.078,max_value=2.42)
    age = forms.IntegerField(label="Age", min_value=20,max_value=100)
